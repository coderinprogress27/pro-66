import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Image,
  TouchableOpacity,
  TextInput,
  Button,
} from 'react-native';

import Constants from 'expo-constants';
import { Header } from 'react-native-elements';
import * as Speech from 'expo-speech';

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      name: '',
    };
  }
  speak = () => {
    var thingToSay = this.state.name;
    Speech.speak(thingToSay);
  };
  render() {
    return (
      <View>
        <Header
          backgroundColor={'black'}
          centerComponent={{
            text: 'Speech Converter',
            style: { color: 'white', fontSize: 24 },
          }}
        />

        <Image
          style={{
            marginTop: 40,
            width: 200,
            height: 200,
            alignSelf: 'center',
          }}
          source={{
            uri:
              'https://static-s.aa-cdn.net/img/ios/804637783/5cd6a6734056dbba0cd4c143e7e5607e',
          }}
        />

        <Text
          style={{
            textAlign: 'center',
            fontSize: 24,
            marginTop: 20,
            color: 'red',
          }}>
          {' '}
          Enter Your word in box and convert and see how to say it.
        </Text>

        <TextInput
          style={styles.searchBox}
          onChangeText={(text) => {
          
           this.setState({
              name: text,
            })
            
          }}
        />

        <TouchableOpacity
          onPress={() => {
              var word = this.state.name.trim();
              
            word?(
            this.speak()
            ):alert("No text is entered ! Make sure you wrote something");
          }}>
          <Text style={styles.searchButton}> Convert </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  searchBox: {
    height: 40,
    marginTop: 20,
    marginLeft: 30,
    width: 270,
    borderColor: 'black',
    borderRadius: 20,
    borderWidth: 3,
    textAlign: 'center',
    alignSelf: 'center',
    color: 'blue',
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  searchButton: {
    color: 'white',
    backgroundColor: 'purple',
    width: 190,
    marginLeft: 70,
    marginTop: 10,
    borderRadius: 20,
    fontSize: 26,
    alignSelf: 'center',
    textAlign: 'center',
  },
});
